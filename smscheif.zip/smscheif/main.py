import requests

# your API secret from (Tools -> API Keys) page
apiSecret = "a6d4dcebaa2fbb6d80cd6588750cabab98c8ba9a"
deviceId = "00000000-0000-0000-23a6-c3fd8dd06f84"
phone = '+919719623633'
message = '!!!!!ALERT!!!!!'

message = {
    "secret": apiSecret,
    "mode": "devices",
    "device": deviceId,
    "sim": 1,
    "priority": 1,
    "phone": phone,
    "message": message
}

r = requests.post(url = "https://www.cloud.smschef.com/api/send/sms", params = message)
  
# do something with response object
result = r.json()

print(result)